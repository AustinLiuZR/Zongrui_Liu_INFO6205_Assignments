
# Initialization
SG1 = ['G11', 'G12', 'G13', 'G14', 'G15', 'G16', 'G17', 'G18']
SG2 = ['G21', 'G22', 'G23', 'G24', 'G25', 'G26', 'G27', 'G28']


# Preferences
SG1_Pref = {  # indicates the preferences of the men
    'G11': ['G23', 'G27', 'G24', 'G28', 'G21', 'G26', 'G25', 'G22'],
    'G12': ['G26', 'G21', 'G22', 'G27', 'G23', 'G24', 'G28', 'G25'],
    'G13': ['G22', 'G28', 'G25', 'G27', 'G21', 'G23', 'G26', 'G24'],
    'G14': ['G25', 'G22', 'G26', 'G24', 'G28', 'G21', 'G23', 'G27'],
    'G15': ['G28', 'G26', 'G22', 'G25', 'G24', 'G27', 'G21', 'G23'],
    'G16': ['G21', 'G23', 'G27', 'G22', 'G26', 'G24', 'G25', 'G28'],
    'G17': ['G27', 'G24', 'G28', 'G26', 'G25', 'G22', 'G23', 'G21'],
    'G18': ['G24', 'G25', 'G27', 'G28', 'G23', 'G21', 'G22', 'G26']
}


SG2_Pref = {  # indicates the preferences of the women
    'G21': ['G16', 'G14', 'G11', 'G15', 'G17', 'G18', 'G12', 'G13'],
    'G22': ['G18', 'G13', 'G14', 'G12', 'G15', 'G17', 'G11', 'G16'],
    'G23': ['G11', 'G17', 'G13', 'G16', 'G14', 'G12', 'G15', 'G18'],
    'G24': ['G14', 'G11', 'G18', 'G17', 'G13', 'G15', 'G16', 'G12'],
    'G25': ['G13', 'G12', 'G15', 'G18', 'G17', 'G16', 'G14', 'G11'],
    'G26': ['G12', 'G13', 'G17', 'G11', 'G16', 'G14', 'G18', 'G15'],
    'G27': ['G17', 'G15', 'G16', 'G13', 'G12', 'G18', 'G11', 'G14'],
    'G28': ['G15', 'G16', 'G12', 'G14', 'G11', 'G13', 'G18', 'G17']
}


def main():
    SG1_Free = list(SG1)
    SG2_Free = list(SG2)

    # Part 3: Proposal
    Matches = {
        'G11': '',
        'G12': '',
        'G13': '',
        'G14': '',
        'G15': '',
        'G16': '',
        'G17': '',
        'G18': ''
        }
    key_list = list(Matches.keys())

    # the algorithm

    while len(SG1_Free) > 0:
        for sg1 in key_list:
            for sg2 in SG1_Pref[sg1]:
                if sg2 not in list(Matches.values()):
                    Matches[sg1] = sg2
                    SG1_Free.remove(sg1)
                    break
                elif sg2 in list(Matches.values()):
                    current_suitor = list(Matches.keys())[list(Matches.values()).index(sg2)]
                    w_list = SG2_Pref.get(sg2)
                    if w_list.index(sg1) < w_list.index(current_suitor):
                        Matches[sg1] = sg2
                        SG1_Free.remove(sg1)
                        Matches[current_suitor] = ''
                        SG2_Free.append(current_suitor)



    for sg1 in Matches.keys():
        print('{},{}'.format(sg1, Matches[sg1]))


if __name__ == "__main__":
    main()